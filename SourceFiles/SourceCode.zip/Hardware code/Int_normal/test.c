// NeuralNetwork.cpp : This file contains the 'main' function. Program execution begins and ends there.
#include "network.h"
#include "InputImages.h"


int main() 
{
	printf("%d",forward(test_arrayz));
}
